"""Tests for causal sequence reconstruction and patient-zero identification."""

from log_detective.causal import CausalReconstructor
from log_detective.models import LogEvent, LogCluster, LogSeverity


def test_causal_reconstruction_patient_zero():
    reconstructor = CausalReconstructor(window_size=20)

    # Cluster dictionary
    c1 = LogCluster(
        cluster_id=1,
        template="Connection timeout to <IP>",
        tokens=["Connection", "timeout", "to", "<IP>"],
        first_seen_line=100,
        first_seen_timestamp="2026-11-21T10:00:00Z",
        first_seen_raw="Connection timeout to 10.0.1.5",
        count=5
    )
    all_clusters = {1: c1}

    # Simulate sequence of events
    # 1. Normal event
    reconstructor.record_event(LogEvent(
        line_number=99,
        byte_offset=0,
        level=LogSeverity.INFO,
        clean_message="Handling user request"
    ))

    # 2. Patient Zero trigger event at line 100
    reconstructor.record_event(LogEvent(
        line_number=100,
        byte_offset=50,
        level=LogSeverity.ERROR,
        clean_message="Connection timeout to 10.0.1.5",
        raw_message="Connection timeout to 10.0.1.5"
    ), cluster_id=1)

    # 3. Degradation warning
    reconstructor.record_event(LogEvent(
        line_number=101,
        byte_offset=100,
        level=LogSeverity.WARN,
        clean_message="Queue size 95% full"
    ))

    # 4. Fatal Crash event
    crash_event = LogEvent(
        line_number=105,
        byte_offset=250,
        level=LogSeverity.FATAL,
        clean_message="java.lang.OutOfMemoryError: Java heap space",
        raw_message="FATAL: java.lang.OutOfMemoryError: Java heap space"
    )

    inv = reconstructor.investigate_crash(
        crash_event=crash_event,
        crash_cluster_id=2,
        all_clusters=all_clusters
    )

    assert inv is not None
    assert inv.crash_line == 105
    assert len(inv.patient_zero_clusters) >= 1
    assert inv.patient_zero_clusters[0].cluster_id == 1
    assert "Patient Zero" in inv.root_cause_hypothesis
    assert inv.confidence_score > 0.80

    # Verify timeline markings
    timeline = inv.preceding_timeline
    trigger_events = [t for t in timeline if t.significance == "trigger"]
    assert len(trigger_events) == 1
    assert trigger_events[0].line_number == 100
