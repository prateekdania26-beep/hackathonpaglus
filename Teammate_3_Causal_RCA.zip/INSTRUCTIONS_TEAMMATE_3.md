# 💥 Teammate 3 Assignment: Causal Crash Reconstruction & Patient Zero Detection

## Your Module
- `causal.py`: Reconstructs the chronological event sequences leading to fatal crashes. Maintains a circular sliding window of preceding events, tags triggers/degradations/cascades, and synthesizes automated Root Cause Hypotheses with confidence scores.
- `test_causal.py`: Test suite verifying pre-crash timeline capture and Patient Zero identification.

## How to add this to the project & push:

1. **Pull the latest code from GitHub:**
   ```bash
   git checkout main
   git pull origin main
   ```

2. **Create your feature branch:**
   ```bash
   git checkout -b feature/crash-reconstruction
   ```

3. **Place your files:**
   - Copy `causal.py` $\to$ `log_detective/causal.py`
   - Copy `test_causal.py` $\to$ `tests/test_causal.py`

4. **Run tests to verify:**
   ```bash
   pytest -c pytest.ini tests/test_causal.py
   ```

5. **Commit and push to GitHub:**
   ```bash
   git add log_detective/causal.py tests/test_causal.py
   git commit -m "feat: implement causal crash reconstruction and root-cause analysis"
   git push -u origin feature/crash-reconstruction
   ```

6. Open GitHub and create a Pull Request to merge into `main`!
