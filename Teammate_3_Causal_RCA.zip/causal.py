"""Causal event sequence reconstructor and Root Cause Analysis (RCA) engine."""

from __future__ import annotations
from collections import deque
from typing import List, Dict, Optional, Set, Deque
from .models import (
    LogEvent,
    LogCluster,
    TimelineEvent,
    CrashInvestigation,
    LogSeverity,
)


class CausalReconstructor:
    """
    Reconstructs the likely sequence of events leading to crashes and fatal errors.
    Maintains bounded memory using circular sliding windows.
    """

    def __init__(self, window_size: int = 50, trace_window_size: int = 30):
        self.window_size = window_size
        self.trace_window_size = trace_window_size
        # Global circular buffer of recent events
        self.recent_events: Deque[TupleEvent] = deque(maxlen=window_size)
        # Component-specific circular buffers
        self.component_buffers: Dict[str, Deque[TupleEvent]] = {}
        # Trace ID correlation buffers
        self.trace_buffers: Dict[str, Deque[TupleEvent]] = {}
        self.investigations: List[CrashInvestigation] = []
        self._crash_count = 0

    def record_event(self, event: LogEvent, cluster_id: Optional[int] = None):
        """Record an event into the sliding context windows."""
        item = TupleEvent(event=event, cluster_id=cluster_id)
        self.recent_events.append(item)

        if event.component:
            if event.component not in self.component_buffers:
                self.component_buffers[event.component] = deque(maxlen=self.trace_window_size)
            self.component_buffers[event.component].append(item)

        if event.trace_id:
            if event.trace_id not in self.trace_buffers:
                self.trace_buffers[event.trace_id] = deque(maxlen=self.trace_window_size)
            self.trace_buffers[event.trace_id].append(item)

    def investigate_crash(
        self,
        crash_event: LogEvent,
        crash_cluster_id: Optional[int],
        all_clusters: Dict[int, LogCluster]
    ) -> CrashInvestigation:
        """
        Perform forensic reconstruction on a detected crash event.
        Extracts pre-crash breadcrumbs, correlates with Patient Zeros,
        and derives a causal chain hypothesis.
        """
        self._crash_count += 1
        
        # Select relevant preceding events
        timeline_items: List[TupleEvent] = []
        
        # If trace_id is present, prioritize trace correlation
        if crash_event.trace_id and crash_event.trace_id in self.trace_buffers:
            timeline_items = list(self.trace_buffers[crash_event.trace_id])
        else:
            # Fall back to global sliding window
            timeline_items = list(self.recent_events)

        # Convert to TimelineEvent models with significance tagging
        reconstructed_timeline: List[TimelineEvent] = []
        cascading_clusters: Set[int] = set()
        patient_zero_clusters: List[LogCluster] = []
        patient_zero_seen_ids: Set[int] = set()

        first_error_item: Optional[TupleEvent] = None
        for item in timeline_items:
            ev = item.event
            cid = item.cluster_id
            
            significance = "context"
            is_pz = False

            if ev.is_crash:
                significance = "crash"
            elif ev.level == LogSeverity.WARN:
                significance = "degradation"
            elif ev.is_error:
                significance = "cascade"
                if cid:
                    cascading_clusters.add(cid)
                if first_error_item is None:
                    first_error_item = item

            # Check if this event was the first occurrence (Patient Zero) of its cluster
            if cid and cid in all_clusters:
                clust = all_clusters[cid]
                if clust.first_seen_line == ev.line_number:
                    is_pz = True
                    significance = "trigger"
                    if cid not in patient_zero_seen_ids:
                        patient_zero_clusters.append(clust)
                        patient_zero_seen_ids.add(cid)

            # Extract snippet of stack trace if present
            stack_snip = None
            if ev.stack_trace:
                stack_lines = ev.stack_trace.strip().splitlines()
                stack_snip = "\n".join(stack_lines[-3:])

            t_event = TimelineEvent(
                line_number=ev.line_number,
                timestamp=ev.timestamp_raw,
                epoch=ev.timestamp_epoch,
                level=ev.level,
                component=ev.component,
                message=ev.clean_message[:140],
                cluster_id=cid,
                is_patient_zero=is_pz,
                significance=significance,
                stack_snippet=stack_snip
            )
            reconstructed_timeline.append(t_event)

        # Build Root Cause Hypothesis and confidence score
        hypothesis, confidence = self._synthesize_hypothesis(
            crash_event=crash_event,
            crash_cluster_id=crash_cluster_id,
            reconstructed_timeline=reconstructed_timeline,
            patient_zero_clusters=patient_zero_clusters,
            all_clusters=all_clusters
        )

        # Summarize blast radius
        affected_comps = set()
        for t in reconstructed_timeline:
            if t.component:
                affected_comps.add(t.component)
        blast_radius = f"{len(affected_comps)} components ({', '.join(sorted(affected_comps)) if affected_comps else 'system-wide'}), {len(cascading_clusters)} error clusters implicated."

        investigation = CrashInvestigation(
            crash_id=self._crash_count,
            crash_line=crash_event.line_number,
            crash_timestamp=crash_event.timestamp_raw,
            crash_message=crash_event.clean_message,
            crash_cluster_id=crash_cluster_id,
            stack_trace=crash_event.stack_trace,
            preceding_timeline=reconstructed_timeline[-25:],  # Top 25 key breadcrumbs
            patient_zero_clusters=patient_zero_clusters,
            cascading_cluster_ids=sorted(list(cascading_clusters)),
            root_cause_hypothesis=hypothesis,
            confidence_score=confidence,
            blast_radius_summary=blast_radius
        )

        self.investigations.append(investigation)
        return investigation

    def _synthesize_hypothesis(
        self,
        crash_event: LogEvent,
        crash_cluster_id: Optional[int],
        reconstructed_timeline: List[TimelineEvent],
        patient_zero_clusters: List[LogCluster],
        all_clusters: Dict[int, LogCluster]
    ) -> Tuple[str, float]:
        """Synthesize human-readable causal explanation."""
        error_count = sum(1 for t in reconstructed_timeline if t.level.is_error_or_higher)
        warn_count = sum(1 for t in reconstructed_timeline if t.level == LogSeverity.WARN)

        # If we caught Patient Zero directly in the timeline
        if patient_zero_clusters:
            pz = patient_zero_clusters[0]
            confidence = 0.92
            
            time_diff_str = ""
            if pz.first_seen_epoch and crash_event.timestamp_epoch:
                dt = crash_event.timestamp_epoch - pz.first_seen_epoch
                if dt >= 0:
                    time_diff_str = f" ({dt:.1f}s earlier)"

            text = (
                f"Crash at line {crash_event.line_number:,} was triggered by Patient Zero "
                f"[Cluster #{pz.cluster_id}: '{pz.template}'] at line {pz.first_seen_line:,}{time_diff_str}. "
                f"This initiated a cascade of {error_count} subsequent errors across the system, "
                f"culminating in the fatal termination."
            )
            return text, confidence

        # If there are preceding errors
        if error_count > 0:
            first_err = next(t for t in reconstructed_timeline if t.level.is_error_or_higher)
            confidence = 0.78
            text = (
                f"Crash at line {crash_event.line_number:,} was preceded by repeated failure "
                f"'{first_err.message}' (starting at line {first_err.line_number:,}), "
                f"which induced {error_count} cascading faults leading to crash."
            )
            return text, confidence

        if warn_count > 0:
            first_warn = next(t for t in reconstructed_timeline if t.level == LogSeverity.WARN)
            confidence = 0.65
            text = (
                f"Crash at line {crash_event.line_number:,} followed resource degradation warning "
                f"'{first_warn.message}' at line {first_warn.line_number:,}."
            )
            return text, confidence

        # Sudden crash with no prior warnings
        confidence = 0.50
        text = (
            f"Sudden fatal crash at line {crash_event.line_number:,} ('{crash_event.clean_message}'). "
            f"No precursor error cascades detected immediately prior to termination."
        )
        return text, confidence


class TupleEvent:
    __slots__ = ('event', 'cluster_id')

    def __init__(self, event: LogEvent, cluster_id: Optional[int]):
        self.event = event
        self.cluster_id = cluster_id
